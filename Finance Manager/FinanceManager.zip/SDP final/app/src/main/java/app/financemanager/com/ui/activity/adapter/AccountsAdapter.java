package app.financemanager.com.ui.activity.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import app.financemanager.com.R;
import app.financemanager.com.ui.activity.BaseActivity;

public class AccountsAdapter extends EntityListAdapter<AccountWrapper, AccountViewHolder> {
    public AccountsAdapter(BaseActivity context, LiveData<List<AccountWrapper>> data) {
        super(context, data);
    }

    @NonNull
    @Override
    public AccountViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View viewItem = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.card_account, parent, false);
        return new AccountViewHolder(viewItem, context);
    }

    @Override
    public void onBindViewHolder(@NonNull final AccountViewHolder holder, int index) {
        super.onBindViewHolder(holder, index);
        AccountWrapper wrapper = getItem(index);
        holder.setAccountName(wrapper.getAccount().getName());

        wrapper.getCurrentBalance().observe(context, new Observer<Long>() {
            @Override
            public void onChanged(@Nullable Long balance) {
                holder.setBalance(balance);
            }
        });

        wrapper.getStartOfMonthBalance().observe(context, new Observer<Long>() {
            @Override
            public void onChanged(@Nullable Long balance) {
                holder.setBalanceMonthStart(balance);
            }
        });
    }
}
