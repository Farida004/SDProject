
package app.financemanager.com.ui.activity.adapter;

public interface OnItemClickListener<T> {
    void onItemClick(T item);
}
