package app.financemanager.com.ui.activity.adapter;

import android.annotation.SuppressLint;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import app.financemanager.com.ui.activity.BaseActivity;

public abstract class EntityListAdapter<E extends IdProvider, H extends RecyclerView.ViewHolder> extends ListAdapter<E, H> {
    protected final BaseActivity context;
    private List<OnItemClickListener<E>> listeners = new ArrayList<>();

    public EntityListAdapter(BaseActivity context, LiveData<List<E>> data) {
        super(new DiffUtil.ItemCallback<E>() {
            @Override
            public boolean areItemsTheSame(E oldItem, E newItem) {
                return oldItem.getId() == newItem.getId();
            }

            @SuppressLint("DiffUtilEquals")
            @Override
            public boolean areContentsTheSame(E oldItem, E newItem) {
                // TODO: implement equals for entities and AccountWrapper
                return oldItem.equals(newItem);
            }
        });

        this.context = context;
        data.observe(context, new Observer<List<E>>() {
            @Override
            public void onChanged(@Nullable List<E> newItems) {
                submitList(newItems);
            }
        });
    }


    @Override
    public void onBindViewHolder(@NonNull H holder, final int position) {
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (position != RecyclerView.NO_POSITION) {
                    E item = getItem(position);
                    for (OnItemClickListener<E> listener : listeners) {
                        listener.onItemClick(item);
                    }
                }
            }
        });
    }

    public void onItemClick(OnItemClickListener<E> listener) {
        listeners.add(listener);
    }
}
