package app.financemanager.com.ui.activity.dialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.flask.colorpicker.ColorPickerView;
import com.flask.colorpicker.OnColorChangedListener;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import app.financemanager.com.R;
import app.financemanager.com.databinding.DialogCategoryBinding;
import app.financemanager.com.domain.model.Category;
import app.financemanager.com.helper.CurrencyInputFilter;
import app.financemanager.com.ui.activity.viewmodel.CategoryDialogViewModel;

public class CategoryDialog extends AppCompatDialogFragment {
    public static final String EXTRA_CATEGORY_ID = "app.financemanager.com.EXTRA_CATEGORY_ID";

    private CategoryDialogViewModel viewModel;
    private List<Category> allCategories = new ArrayList<>();
    private ColorPickerView colorPicker;
    private EditText editTextBudget;

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        viewModel = ViewModelProviders.of(this).get(CategoryDialogViewModel.class);

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        final DialogCategoryBinding binding = DataBindingUtil.inflate(LayoutInflater.from(getContext()), R.layout.dialog_category, null, false);
        View view = binding.getRoot();
        colorPicker = view.findViewById(R.id.color_picker_view);

        viewModel.setCategoryId(getArguments().getLong(EXTRA_CATEGORY_ID, -1L)).observe(this, new Observer<Category>() {
            @Override
            public void onChanged(@Nullable Category category) {
                viewModel.setCategory(category);
                if (viewModel.getColor() != null) colorPicker.setInitialColor(viewModel.getColor(), false);
                binding.setViewModel(viewModel);
            }
        });

        builder.setView(view);

        builder.setTitle(getArguments().getLong(EXTRA_CATEGORY_ID, -1L) == -1L ? R.string.dialog_category_create_title : R.string.dialog_category_edit_title);

        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int which) {
                viewModel.cancel();
            }
        });

        builder.setPositiveButton(R.string.submit, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int which) {

            }
        });

        viewModel.getAllCategories().observe(this, new Observer<List<Category>>() {
            @Override
            public void onChanged(@Nullable List<Category> categories) {
                synchronized (allCategories) {
                    allCategories = categories;
                }
            }
        });

        editTextBudget = view.findViewById(R.id.editText_budget);

        editTextBudget.setFilters(new InputFilter[] {new CurrencyInputFilter(0.0, null)});

        if (viewModel.getColor() != null) colorPicker.setInitialColor(viewModel.getColor(), false);
        colorPicker.addOnColorChangedListener(new OnColorChangedListener() {
            @Override
            public void onColorChanged(int i) {
                if (i == -1) {
                    viewModel.setColor(null);
                } else {
                    viewModel.setColor(i);
                }
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateCategoryName()) {
                    viewModel.submit();
                    Toast.makeText(getContext(), R.string.category_saved_msg, Toast.LENGTH_SHORT).show();
                    dismiss();
                }
            }
        });
        return dialog;
    }

    private boolean validateCategoryName() {
        synchronized (allCategories) {
            if (viewModel.getName() == null || viewModel.getName().isEmpty()) {
                Toast.makeText(getContext(), getString(R.string.dialog_category_empty_name_impossible_msg), Toast.LENGTH_LONG).show();
                return false;
            }

            if (allCategories == null || allCategories.isEmpty()) {
                return true;
            }
            for (int i = 0; i < allCategories.size(); i++) {
                if (allCategories.get(i).getName().toLowerCase().equals(viewModel.getName().toLowerCase()) && allCategories.get(i).getId() != viewModel.getCategory().getId()) {
                    Toast.makeText(getContext(), getString(R.string.dialog_category_name_taken_msg), Toast.LENGTH_LONG).show();
                    return false;
                }
            }
            return true;
        }
    }
}
