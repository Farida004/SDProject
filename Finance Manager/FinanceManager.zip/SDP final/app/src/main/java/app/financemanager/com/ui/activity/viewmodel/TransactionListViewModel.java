package app.financemanager.com.ui.activity.viewmodel;

import android.app.Application;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import app.financemanager.com.domain.database.FinanceDatabase;
import app.financemanager.com.domain.database.dao.TransactionDao;
import app.financemanager.com.domain.model.Transaction;

public class TransactionListViewModel extends BaseViewModel {
    protected final TransactionDao transactionDao = FinanceDatabase.getInstance().transactionDao();
    private LiveData<Long> balance;
    private LiveData<List<Transaction>> transactions;
    private long preselectedCategoryId = -1L;
    private long preselectedAccountId = -1L;

    public TransactionListViewModel(@NonNull Application application) {
        super(application);
    }

    public LiveData<Long> getBalance() {
        return balance;
    }

    public void setBalance(LiveData<Long> balance) {
        this.balance = balance;
    }

    protected LiveData<List<Transaction>> fetchTransactions() {
        return transactionDao.getAll();
    }

    public LiveData<List<Transaction>> getTransactions() {
        if (transactions == null) transactions = fetchTransactions();
        return transactions;
    }

    public long getPreselectedCategoryId() {
        return preselectedCategoryId;
    }

    public void setPreselectedCategoryId(long preselectedCategoryId) {
        this.preselectedCategoryId = preselectedCategoryId;
    }

    public long getPreselectedAccountId() {
        return preselectedAccountId;
    }

    public void setPreselectedAccountId(long preselectedAccountId) {
        this.preselectedAccountId = preselectedAccountId;
    }

}
