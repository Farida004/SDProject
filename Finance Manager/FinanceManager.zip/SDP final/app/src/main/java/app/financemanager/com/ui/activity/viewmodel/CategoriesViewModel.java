package app.financemanager.com.ui.activity.viewmodel;

import android.app.Application;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.arch.core.util.Function;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Transformations;
import app.financemanager.com.R;
import app.financemanager.com.domain.database.FinanceDatabase;
import app.financemanager.com.domain.model.Category;
import app.financemanager.com.ui.activity.adapter.CategoryWrapper;


public class CategoriesViewModel extends BaseViewModel {
    private LiveData<List<CategoryWrapper>> categories;

    public CategoriesViewModel(@NonNull Application application) {
        super(application);
        setNavigationDrawerId(R.id.nav_category);
        setTitle(R.string.activity_categories_title);
        categories = Transformations.map(FinanceDatabase.getInstance().categoryDao().getAll(), new Function<List<Category>, List<CategoryWrapper>>() {
            @Override
            public List<CategoryWrapper> apply(List<Category> input) {
                List<CategoryWrapper> wrappers = new ArrayList<>();
                for (Category category : input) {
                    wrappers.add(new CategoryWrapper(category));
                }
                return wrappers;
            }
        });
    }

    public LiveData<List<CategoryWrapper>> getCategories() {
        return categories;
    }
}
