package app.financemanager.com.ui.activity.adapter;

import androidx.lifecycle.LiveData;
import app.financemanager.com.domain.database.FinanceDatabase;
import app.financemanager.com.domain.model.Category;

public class CategoryWrapper implements IdProvider {
    private Category category;
    private LiveData<Long> balance;

    public CategoryWrapper(Category category) {
        this.category = category;
        balance = FinanceDatabase.getInstance().transactionDao().sumForCategoryThisMonth(category.getId());
    }

    public LiveData<Long> getBalance() {
        return balance;
    }

    @Override
    public Long getId() {
        return category.getId();
    }

    public Category getCategory() {
        return category;
    }
}
