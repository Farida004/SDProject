package app.financemanager.com.domain.database.dao;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Query;
import app.financemanager.com.domain.model.Category;

@Dao
public abstract class CategoryDao extends AbstractDao<Category> {
    @Override
    @Query("SELECT * FROM Category WHERE id=:id")
    public abstract LiveData<Category> get(long id);

    @Query("SELECT * FROM Category WHERE name LIKE :name")
    public abstract Category get(String name);

    @Override
    @Query("SELECT * FROM Category")
    public abstract LiveData<List<Category>> getAll();
}
