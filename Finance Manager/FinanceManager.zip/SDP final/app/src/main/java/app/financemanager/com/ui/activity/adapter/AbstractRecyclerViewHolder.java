package app.financemanager.com.ui.activity.adapter;

import android.content.Context;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public abstract class AbstractRecyclerViewHolder extends RecyclerView.ViewHolder {
    protected final Context context;

    public AbstractRecyclerViewHolder(@NonNull View itemView, Context context) {
        super(itemView);
        this.context = context;
    }
}
