package app.financemanager.com.ui.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.view.View;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;
import app.financemanager.com.R;
import app.financemanager.com.domain.database.FinanceDatabase;
import app.financemanager.com.domain.model.Account;
import app.financemanager.com.helper.SwipeController;
import app.financemanager.com.ui.activity.adapter.AccountWrapper;
import app.financemanager.com.ui.activity.adapter.AccountsAdapter;
import app.financemanager.com.ui.activity.adapter.OnItemClickListener;
import app.financemanager.com.ui.activity.dialog.AccountDialog;
import app.financemanager.com.ui.activity.dialog.CategoryDialog;
import app.financemanager.com.ui.activity.viewmodel.AccountsViewModel;
import app.financemanager.com.ui.activity.viewmodel.BaseViewModel;

public class AccountsActivity extends BaseActivity implements OnItemClickListener<AccountWrapper> {
    private AccountsViewModel viewModel;
    private RecyclerView recyclerView;
    private AccountsAdapter accountsAdapter;

    @Override
    protected Class<? extends BaseViewModel> getViewModelClass() {
        return AccountsViewModel.class;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        viewModel = (AccountsViewModel) super.viewModel;

        accountsAdapter = new AccountsAdapter(this, viewModel.getAccounts());

        accountsAdapter.onItemClick(this);

        setContent(R.layout.content_recycler);
        addFab(R.layout.fab_add, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAccountDialog(null);
            }
        });

        recyclerView = findViewById(R.id.recycler_view);
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(this, 1);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(accountsAdapter);

        SwipeController.SwipeControllerAction deleteAction = new SwipeController.SwipeControllerAction() {
            @Override
            public void onClick(int position) {
                deleteAccount(viewModel.getAccounts().getValue().get(position).getAccount());
            }
            @Override
            public Drawable getIcon() {
                return ContextCompat.getDrawable(AccountsActivity.this, R.drawable.ic_delete_red_24dp);
            }
        };

        final SwipeController swipeController = new SwipeController(this, deleteAction, deleteAction);

        ItemTouchHelper itemTouchhelper = new ItemTouchHelper(swipeController);
        itemTouchhelper.attachToRecyclerView(recyclerView);

        recyclerView.addItemDecoration(new RecyclerView.ItemDecoration() {
            @Override
            public void onDraw(Canvas c, RecyclerView parent, RecyclerView.State state) {
                swipeController.onDraw(c);
            }
        });
    }

    private void deleteAccount(final Account account) {
        if (viewModel.getAccounts().getValue().size() > 1) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(R.string.account_delete_action);
            builder.setMessage(Html.fromHtml(getResources().getString(R.string.account_delete_question, account.getName())));
            builder.setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    FinanceDatabase.getInstance().accountDao().deleteAsync(account);
                    Toast.makeText(getBaseContext(), R.string.account_deleted_msg, Toast.LENGTH_SHORT).show();
                }
            });
            builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                }
            });
            builder.create().show();
        } else {
            Toast.makeText(getBaseContext(), R.string.account_last_not_deleteable, Toast.LENGTH_LONG).show();
        }
    }

    private void openAccountDialog(Account account) {
        Bundle args = new Bundle();
        if (account == null) {
        } else {
            args.putLong(CategoryDialog.EXTRA_CATEGORY_ID, account.getId());
        }

        AccountDialog accountDialog = new AccountDialog();
        accountDialog.setArguments(args);
        accountDialog.show(getSupportFragmentManager(), "CategoryDialog");
    }

    @Override
    public void onItemClick(AccountWrapper item) {
        final Intent intent = new Intent(this, AccountActivity.class);
        intent.putExtra(AccountActivity.EXTRA_ACCOUNT_ID, item.getId());
        Long month = item.getCurrentBalance().getValue();
        Long total= item.getStartOfMonthBalance().getValue();
        if(month<=(total*0.5)){
            AlertDialog.Builder builder1 = new AlertDialog.Builder(recyclerView.getContext());
            builder1.setMessage("You are exceeding your balance limit! Please try to decrease your expenses.");
            builder1.setCancelable(true);
            builder1.setNegativeButton(
                    "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });

            AlertDialog alert11 = builder1.create();
            alert11.setTitle("Warning Alert!");
            alert11.show();
        }else if(month>(total*0.5)){
            AlertDialog.Builder builder1 = new AlertDialog.Builder(recyclerView.getContext());
            builder1.setMessage("You are doing well for this month!");
            builder1.setCancelable(true);
            builder1.setNegativeButton(
                    "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                            startActivity(intent);
                    }
                    });

            AlertDialog alert11 = builder1.create();
            alert11.setTitle("Status Notification!");
            alert11.show();
        }else {

        }

    }

}