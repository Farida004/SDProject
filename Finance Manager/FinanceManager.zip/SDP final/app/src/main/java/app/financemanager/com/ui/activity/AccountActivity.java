package app.financemanager.com.ui.activity;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import app.financemanager.com.R;
import app.financemanager.com.domain.database.FinanceDatabase;
import app.financemanager.com.domain.model.Account;
import app.financemanager.com.domain.model.Category;
import app.financemanager.com.domain.model.Transaction;
import app.financemanager.com.helpers.CurrencyHelper;
import app.financemanager.com.ui.activity.dialog.AccountDialog;
import app.financemanager.com.ui.activity.viewmodel.AccountViewModel;
import app.financemanager.com.ui.activity.viewmodel.TransactionListViewModel;

public class AccountActivity extends TransactionListActivity {
    public static final String EXTRA_ACCOUNT_ID = "app.financemanager.com.EXTRA_ACCOUNT_ID";
    protected AccountViewModel viewModel;

    @Override
    protected AccountViewModel getViewModel() {
        long accountId = getIntent().getLongExtra(EXTRA_ACCOUNT_ID, -1);
        AccountViewModel.AccountViewModelFactory viewModelFactory = new AccountViewModel.AccountViewModelFactory(this.getApplication(), accountId);
        return ViewModelProviders.of(this, viewModelFactory).get(AccountViewModel.class);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel = (AccountViewModel) super.viewModel;
        viewModel.getAccount().observe(this, new Observer<Account>() {
            @Override
            public void onChanged(Account account) {
                viewModel.setTitle(account.getName());
            }
        });
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        addEditMenuClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                openAccountDialog();
                return true;
            }
        });

        View view = setHeaderLayout(R.layout.header_account_balance);
        final TextView tvTotalBalance = view.findViewById(R.id.tv_totalBalance);
        final TextView tvMonthBalance = view.findViewById(R.id.tv_monthBalance);

        final PieChart pieChart = view.findViewById(R.id.pieChart);
        //  pieChart.setUsePercentValues(true);

        final ArrayList<PieEntry> pieChartValues = new ArrayList<>();
        final ArrayList<Long> pieChartCategories = new ArrayList<>();
        final HashMap<Long, Long> transactionHash = new HashMap<>();

        viewModel.getTotalBalance().observe(this, new Observer<Long>() {
            @Override
            public void onChanged(@Nullable Long totalBalance) {
                CurrencyHelper.setBalance(totalBalance, tvTotalBalance);
            }
        });

        viewModel.getMonthBalance().observe(this, new Observer<Long>() {
            @Override
            public void onChanged(@Nullable Long monthBalance) {
                CurrencyHelper.setBalance(monthBalance, tvMonthBalance);
            }
        });

        viewModel.getTransactions().observe(this, new Observer<List<Transaction>>() {
            @Override
            public void onChanged(@Nullable List<Transaction> transactions) {
                if (transactions != null) {
                    transactionHash.clear();
                    pieChartValues.clear();
                    pieChart.clear();

                    for (int i = 0; i < transactions.size(); i++) {

                        if (!transactionHash.containsKey(transactions.get(i).getCategoryId())) {
                           transactionHash.put(transactions.get(i).getCategoryId(), transactions.get(i).getAmount() / 100);
                        } else {
                            Long existingValue = transactionHash.get(transactions.get(i).getCategoryId());
                            Long newValue = transactions.get(i).getAmount() / 100;
                            transactionHash.put(transactions.get(i).getCategoryId(),
                                    existingValue + newValue);
                        }
                        //   pieChartValues.add(new PieEntry(transactions.get(i).getCategoryId(), String.valueOf( transactions.get(i).getAmount())));
                    }


                    for (final Map.Entry<Long, Long> stringLongEntry : transactionHash.entrySet()) {

                        FinanceDatabase.getInstance().categoryDao().get((stringLongEntry).getKey()).observe(AccountActivity.this, new Observer<Category>() {
                            @Override
                            public void onChanged(@Nullable Category category) {
                        //       pieChart.invalidate();
                                pieChartValues.add(new PieEntry((Long) ((Map.Entry) stringLongEntry).getValue(), category.getName()));

                                ArrayList<Integer> colors = new ArrayList<>();

                                for (int c : ColorTemplate.VORDIPLOM_COLORS)
                                    colors.add(c);

                                for (int c : ColorTemplate.JOYFUL_COLORS)
                                    colors.add(c);

                                for (int c : ColorTemplate.COLORFUL_COLORS)
                                    colors.add(c);

                                for (int c : ColorTemplate.LIBERTY_COLORS)
                                    colors.add(c);

                                for (int c : ColorTemplate.PASTEL_COLORS)
                                    colors.add(c);
                                colors.add(ColorTemplate.getHoloBlue());
                                PieDataSet pieDataSet = new PieDataSet(pieChartValues, "");

                                pieDataSet.setColors(colors);
                                PieData pieData = new PieData(pieDataSet);
                                pieChart.setData(pieData);
                                pieChart.setDrawHoleEnabled(true);
                                pieData.setValueTextColor(Color.WHITE);

                                setupPieChart(pieChart, Typeface.SANS_SERIF);

                             //   pieChart.notify();
                                pieChart.notifyDataSetChanged();
                                pieChart.invalidate();

                            }
                        });
                       //pieChartValues.add(new PieEntry((Long) ((Map.Entry) stringLongEntry).getValue(), ((Map.Entry) stringLongEntry).getKey().toString()));
                    }


//                   pieChart.invalidate();
                }
            }
        });
    }

    private void setupPieChart(PieChart mChart, Typeface tf) {
        mChart.getDescription().setEnabled(true);
        mChart.setCenterText("");

        mChart.setCenterTextSize(10f);
        mChart.setCenterTextTypeface(tf);

        Legend l = mChart.getLegend();

        mChart.getLegend().setWordWrapEnabled(true);
        mChart.getLegend().setEnabled(true);

        l.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        l.setFormSize(20f);
        l.setFormToTextSpace(5f);
        l.setForm(Legend.LegendForm.SQUARE);
        l.setTextSize(12f);
        l.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        l.setWordWrapEnabled(true);
        l.setDrawInside(true);
        mChart.setTouchEnabled(false);
        mChart.setDrawEntryLabels(true);
        mChart.getLegend().setWordWrapEnabled(true);

        mChart.setExtraOffsets(20f, 0f, 20f, 0f);
        // mChart.rotationAngle = 0f
        mChart.setDrawCenterText(true);
        mChart.getDescription().setEnabled(true);
        mChart.setRotationEnabled(false);
        mChart.setEntryLabelColor(Color.WHITE);
        mChart.setEntryLabelTextSize(12f);
    }

    private void openAccountDialog() {
        AccountDialog accountDialog = new AccountDialog();

        Bundle args = new Bundle();
        args.putLong(AccountDialog.EXTRA_ACCOUNT_ID, viewModel.getAccount().getValue().getId());
        Long monthBalance = viewModel.getMonthBalance().getValue();
        if (monthBalance == null) monthBalance = 0L;
        args.putLong(AccountDialog.EXTRA_ACCOUNT_MONTH_BALANCE, monthBalance);
        accountDialog.setArguments(args);

        accountDialog.show(getSupportFragmentManager(), "AccountDialog");
    }

    @Override
    protected Class<? extends TransactionListViewModel> getViewModelClass() {
        return AccountViewModel.class;
    }
}
