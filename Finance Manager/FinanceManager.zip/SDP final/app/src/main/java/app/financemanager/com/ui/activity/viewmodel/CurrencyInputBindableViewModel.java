package app.financemanager.com.ui.activity.viewmodel;

import android.app.Application;
import android.graphics.Color;

import androidx.annotation.NonNull;
import androidx.databinding.Bindable;
import app.financemanager.com.helpers.CurrencyHelper;

public abstract class CurrencyInputBindableViewModel extends BindableViewModel {
    private int positiveColor = Color.GREEN;
    private int negativeColor = Color.RED;
    private String amountString = null;

    public CurrencyInputBindableViewModel(@NonNull Application application) {
        super(application);
    }

    @Bindable
    public String getAmountString() {
        if (amountString == null) {
            amountString = CurrencyHelper.convertToString(getNumericAmount());
            if (amountString == null) {
                amountString = "";
            }
        }
        return amountString;
    }
    public void setAmountString(String amountString) {
        if (amountString == null) amountString = "";
        this.amountString = amountString;
        Long number = CurrencyHelper.convertToLong(amountString);
        if (number != null) {
            if (getNumericAmount() != number) {
                setNumericAmount(number);
              //  notifyPropertyChanged(BR.expense);
              //  notifyPropertyChanged(BR.amountColor);
            }
        } else {
            setNumericAmount(null);
         //   notifyPropertyChanged(BR.expense);
         //   notifyPropertyChanged(BR.amountColor);
        }

    }

    @Bindable
    public int getAmountColor() {
        return getExpense() ? negativeColor : positiveColor;
    }

    @Bindable
    public boolean getExpense() {return getAmountString().contains("-");
    }

    public void setExpense(boolean checked) {
        if (getExpense() != checked) {
            if (checked) {
                setAmountString("-" + getAmountString());
            } else {
                setAmountString(getAmountString().substring(1));
            }
            
           // notifyPropertyChanged(BR.amountString);
        }
//        if (getNumericAmount() == null) {
//            setAmountString(checked ? "-" + getAmountString() : "");
//            notifyPropertyChanged(BR.amountColor);
//            notifyPropertyChanged(BR.amountString);
//        } else if ((getNumericAmount() > 0 && checked) || (getNumericAmount() < 0 && !checked)) {
//            setAmountString(CurrencyHelper.convertToString(getNumericAmount() * -1));
//            notifyPropertyChanged(BR.expense);
//            notifyPropertyChanged(BR.amountColor);
//            notifyPropertyChanged(BR.amountString);
//        }
    }

    protected abstract Long getNumericAmount();
    protected abstract void setNumericAmount(Long amount);

    public void setCurrencyColors(int positiveColor, int negativeColor) {
        this.positiveColor = positiveColor;
        this.negativeColor = negativeColor;
      //  notifyPropertyChanged(BR.amountColor);
    }
}
