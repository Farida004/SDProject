package app.financemanager.com.ui.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;
import app.financemanager.com.R;
import app.financemanager.com.domain.database.FinanceDatabase;
import app.financemanager.com.domain.model.Category;
import app.financemanager.com.helper.SwipeController;
import app.financemanager.com.ui.activity.adapter.CategoriesAdapter;
import app.financemanager.com.ui.activity.adapter.CategoryWrapper;
import app.financemanager.com.ui.activity.adapter.OnItemClickListener;
import app.financemanager.com.ui.activity.dialog.CategoryDialog;
import app.financemanager.com.ui.activity.viewmodel.BaseViewModel;
import app.financemanager.com.ui.activity.viewmodel.CategoriesViewModel;

public class CategoriesActivity extends BaseActivity implements OnItemClickListener<CategoryWrapper> {
    private CategoriesAdapter categoriesAdapter;
    private RecyclerView recyclerView;
    private TextView emptyView;
    private CategoriesViewModel viewModel;
    private SwipeController swipeController = null;


    @Override
    protected Class<? extends BaseViewModel> getViewModelClass() {
        return CategoriesViewModel.class;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContent(R.layout.content_recycler);

        viewModel = (CategoriesViewModel) super.viewModel;
        categoriesAdapter = new CategoriesAdapter(this, viewModel.getCategories());
        categoriesAdapter.onItemClick(this);

        addFab(R.layout.fab_add, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCategoryDialog(null);
            }
        });

        recyclerView = findViewById(R.id.recycler_view);
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(this, 1);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(categoriesAdapter);

        emptyView = findViewById(R.id.empty_view);
        emptyView.setText(getString(R.string.activity_categories_empty_list_label));

        viewModel.getCategories().observe(this, new Observer<List<CategoryWrapper>>() {
            @Override
            public void onChanged(@Nullable List<CategoryWrapper> categoryWrappers) {
                if (categoryWrappers.isEmpty()) {
                    recyclerView.setVisibility(View.GONE);
                    emptyView.setVisibility(View.VISIBLE);
                } else {
                    recyclerView.setVisibility(View.VISIBLE);
                    emptyView.setVisibility(View.GONE);
                }
            }
        });

        SwipeController.SwipeControllerAction deleteAction = new SwipeController.SwipeControllerAction() {
            @Override
            public void onClick(int position) {
                deleteCategory(viewModel.getCategories().getValue().get(position).getCategory());
            }
            @Override
            public Drawable getIcon() {
                return ContextCompat.getDrawable(CategoriesActivity.this, R.drawable.ic_delete_red_24dp);
            }
        };

        swipeController = new SwipeController(this, deleteAction, deleteAction);

        ItemTouchHelper itemTouchhelper = new ItemTouchHelper(swipeController);
        itemTouchhelper.attachToRecyclerView(recyclerView);

        recyclerView.addItemDecoration(new RecyclerView.ItemDecoration() {
            @Override
            public void onDraw(Canvas c, RecyclerView parent, RecyclerView.State state) {
                swipeController.onDraw(c);
            }
        });

    }

    public void deleteCategory(final Category category) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.category_delete_dialog_title);
        builder.setMessage(Html.fromHtml(getResources().getString(R.string.category_delete_question, category.getName())));
        builder.setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                FinanceDatabase.getInstance().categoryDao().deleteAsync(category);
                Toast.makeText(getBaseContext(), R.string.category_deleted, Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        builder.create().show();
    }

    private void openCategoryDialog(Category category) {
        Bundle args = new Bundle();
        if (category == null) {
        } else {
            args.putLong(CategoryDialog.EXTRA_CATEGORY_ID, category.getId());
        }

        CategoryDialog categoryDialog = new CategoryDialog();
        categoryDialog.setArguments(args);

        categoryDialog.show(getSupportFragmentManager(), "CategoryDialog");
    }

    @Override
    public void onItemClick(CategoryWrapper item) {
        Intent intent = new Intent(this, CategoryActivity.class);
        intent.putExtra(CategoryActivity.EXTRA_CATEGORY_ID, item.getId());
        startActivity(intent);
    }
}
