package app.financemanager.com.helpers;

import android.content.Context;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.Locale;

import app.financemanager.com.R;

public final class CurrencyHelper {


    private static final DecimalFormat format = new DecimalFormat("#0.00", DecimalFormatSymbols.getInstance(Locale.ENGLISH));

    private CurrencyHelper() {
    }

    public static void setBalance(Long balance, TextView textView, boolean setColor) {
        Context context = textView.getContext();
        if (balance == null) balance = 0L;
        String prefix = setColor && balance > 0 ? "+" : "";
        textView.setText(prefix + balance.doubleValue() / 100.0 + "\u20BC"); //Adding AZN icon.

        if (setColor) {
            if (balance < 0) {
                textView.setTextColor(context.getResources().getColor(R.color.red));
            } else if (balance > 0) {
                textView.setTextColor(context.getResources().getColor(R.color.green));
            } else {
                textView.setTextColor(context.getResources().getColor(android.R.color.tab_indicator_text));
            }
        }
    }

    public static void setBalance(Long balance, TextView textView) {
        setBalance(balance, textView, true);
    }

    public static String convertToString(Long value) {
        if (value == null) return "";
        return format.format(value.doubleValue() / 100.00);
    }

    public static Long convertToLong(String text) {
        try {
            return Math.round(Double.parseDouble(text) * 100);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static String convertToCurrencyString(Long amount) {
        return NumberFormat.getCurrencyInstance().format(amount.doubleValue() / 100.0);
    }
}
