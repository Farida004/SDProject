package app.financemanager.com.ui.activity.adapter;

import org.joda.time.LocalDate;

import androidx.lifecycle.LiveData;
import app.financemanager.com.domain.database.FinanceDatabase;
import app.financemanager.com.domain.model.Account;

public class AccountWrapper implements IdProvider {
    private Account account;
    private LiveData<Long> currentBalance;
    private LiveData<Long> startOfMonthBalance;

    public AccountWrapper(Account account) {
        this.account = account;
        currentBalance = FinanceDatabase.getInstance().transactionDao().sumForAccount(account.getId());
        startOfMonthBalance = FinanceDatabase.getInstance().transactionDao().sumForAccountBefore(account.getId(), LocalDate.now().withDayOfMonth(1).toString());
    }

    public LiveData<Long> getCurrentBalance() {
        return currentBalance;
    }

    public LiveData<Long> getStartOfMonthBalance() {
        return startOfMonthBalance;
    }

    @Override
    public Long getId() {
        return account.getId();
    }

    public Account getAccount() {
        return account;
    }

}
