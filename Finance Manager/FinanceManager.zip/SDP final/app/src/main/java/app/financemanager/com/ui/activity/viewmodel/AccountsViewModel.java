package app.financemanager.com.ui.activity.viewmodel;

import android.app.Application;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.arch.core.util.Function;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Transformations;
import app.financemanager.com.R;
import app.financemanager.com.domain.database.FinanceDatabase;
import app.financemanager.com.domain.model.Account;
import app.financemanager.com.ui.activity.adapter.AccountWrapper;

public class AccountsViewModel extends BaseViewModel {
    private LiveData<List<AccountWrapper>> accounts;

    public AccountsViewModel(@NonNull Application application) {
        super(application);
        setNavigationDrawerId(R.id.nav_account);
        setTitle(R.string.activity_accounts_title);
        accounts = Transformations.map(FinanceDatabase.getInstance().accountDao().getAll(), new Function<List<Account>, List<AccountWrapper>>() {
            @Override
            public List<AccountWrapper> apply(List<Account> input) {
                List<AccountWrapper> wrappers = new ArrayList<>();
                for (Account account : input) {
                    wrappers.add(new AccountWrapper(account));
                }
                return wrappers;
            }
        });
    }

    public LiveData<List<AccountWrapper>> getAccounts() {
        return accounts;
    }
}

