package app.financemanager.com.ui.activity;

import androidx.appcompat.app.AppCompatActivity;
import app.financemanager.com.R;

import android.content.Intent;
import android.os.Bundle;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        startActivity(new Intent(this, StartupActivity.class));
        finish();
    }
}
