package app.financemanager.com.ui.activity.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import app.financemanager.com.R;
import app.financemanager.com.domain.database.FinanceDatabase;
import app.financemanager.com.domain.model.Account;
import app.financemanager.com.domain.model.Category;
import app.financemanager.com.domain.model.Transaction;
import app.financemanager.com.ui.activity.BaseActivity;

public class TransactionsAdapter extends EntityListAdapter<Transaction, TransactionViewHolder> {
    public TransactionsAdapter(BaseActivity context, LiveData<List<Transaction>> data) {
        super(context, data);
    }

    @NonNull
    @Override
    public TransactionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View viewItem = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.card_transaction, parent, false);
        return new TransactionViewHolder(viewItem, context);
    }

    @Override
    public void onBindViewHolder(@NonNull final TransactionViewHolder holder, int index) {
        super.onBindViewHolder(holder, index);
        final Transaction transaction = getItem(index);
        holder.setTransactionName(transaction.getName());
        holder.setDate(transaction.getDate());
        holder.setAmount(transaction.getAmount());

        FinanceDatabase.getInstance().accountDao().get(transaction.getAccountId()).observe(context, new Observer<Account>() {
            @Override
            public void onChanged(@Nullable Account account) {
                if (account != null) {
                    holder.setAccountName(account.getName());
                } else {
                    holder.setAccountName(context.getResources().getString(R.string.not_found_error));
                }
            }
        });

        if (transaction.getCategoryId() != null) {

            FinanceDatabase.getInstance().categoryDao().get(transaction.getCategoryId()).observe(context, new Observer<Category>() {
                @Override
                public void onChanged(@Nullable Category category) {
                    if (category != null) {
                        holder.setCategoryName(category.getName());
                        holder.setCategoryColor(category.getColor());
                    } else {
                        holder.setCategoryName(context.getResources().getString(R.string.not_found_error));
                        holder.setCategoryColor(null);
                    }
                }
            });
        } else {
            holder.setCategoryName(null);
            holder.setCategoryColor(null);
        }
    }
}
