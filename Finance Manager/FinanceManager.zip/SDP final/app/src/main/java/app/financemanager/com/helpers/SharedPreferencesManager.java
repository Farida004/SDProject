package app.financemanager.com.helpers;


import android.content.Context;
import android.content.SharedPreferences;

public class SharedPreferencesManager {
    private static SharedPreferences pref;
    private static SharedPreferences.Editor editor;

    private static final int PRIVATE_MODE = 0;
    private static final String PREF_NAME = "privacy_friendly_apps";

    private SharedPreferencesManager() {
    }

    public static void init(Context context) {
        pref = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }
}
