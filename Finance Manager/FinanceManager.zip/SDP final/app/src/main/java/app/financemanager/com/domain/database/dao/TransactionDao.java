package app.financemanager.com.domain.database.dao;

import org.joda.time.LocalDate;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Query;
import app.financemanager.com.domain.model.Transaction;
import app.financemanager.com.helper.CommunicantAsyncTask;
import app.financemanager.com.helper.TaskListener;

@Dao
public abstract class TransactionDao extends AbstractDao<Transaction> {

    @Override
    @Query("SELECT * FROM Tranzaction WHERE id=:id")
    public abstract LiveData<Transaction> get(long id);

    @Override
    @Query("SELECT * FROM Tranzaction ORDER BY date DESC")
    public abstract LiveData<List<Transaction>> getAll();

    @Query("SELECT * FROM Tranzaction WHERE accountId=:accountId ORDER BY date DESC")
    public abstract LiveData<List<Transaction>> getForAccount(long accountId);

    @Query("SELECT SUM(amount) FROM Tranzaction WHERE categoryId=:categoryId AND date>=:from and date<:before")
    public abstract LiveData<Long> sumForCategoryFromBefore(long categoryId, String from, String before);

    @Query("SELECT SUM(amount) FROM Tranzaction WHERE categoryId=:categoryId AND amount > 0 AND date>=:from and date<:before")
    public abstract LiveData<Long> sumIncomeForCategoryFromBefore(long categoryId, String from, String before);

    @Query("SELECT SUM(amount) FROM Tranzaction WHERE categoryId=:categoryId AND amount < 0 AND date>=:from and date<:before")
    public abstract LiveData<Long> sumExpensesForCategoryFromBefore(long categoryId, String from, String before);

    @Query("SELECT * FROM Tranzaction WHERE categoryId=:categoryId ORDER BY date DESC")
    public abstract LiveData<List<Transaction>> getForCategory(long categoryId);

    @Query("SELECT * FROM Tranzaction WHERE accountId=:accountId AND name=:name AND date>=:from AND date<:before ORDER BY date DESC LIMIT 1")
    public abstract Transaction getLatestByNameAndAccountFromBeforeSync(long accountId, String name, String from, String before);

    @Query("SELECT SUM(amount) FROM Tranzaction WHERE accountId=:accountId")
    public abstract LiveData<Long> sumForAccount(long accountId);

    @Query("SELECT SUM(amount) FROM Tranzaction WHERE accountId=:accountId AND date<:date")
    public abstract LiveData<Long> sumForAccountBefore(long accountId, String date);

    public LiveData<Long> sumForCategoryThisMonth(long categoryId) {
        return sumForCategoryFromBefore(categoryId, LocalDate.now().withDayOfMonth(1).toString(), LocalDate.now().withDayOfMonth(1).plusMonths(1).toString());
    }

    public LiveData<Long> sumIncomeForCategoryThisMonth(long categoryId) {
        return sumIncomeForCategoryFromBefore(categoryId, LocalDate.now().withDayOfMonth(1).toString(), LocalDate.now().withDayOfMonth(1).plusMonths(1).toString());
    }

    public LiveData<Long> sumExpensesForCategoryThisMonth(long categoryId) {
        return sumExpensesForCategoryFromBefore(categoryId, LocalDate.now().withDayOfMonth(1).toString(), LocalDate.now().withDayOfMonth(1).plusMonths(1).toString());
    }

    public CommunicantAsyncTask<?, Transaction> getLatestByNameForAccountLastMonthAsync(final Long accountId, final String name, TaskListener listener) {
        return listenAndExec(new CommunicantAsyncTask<Void, Transaction>() {
            @Override
            protected Transaction doInBackground(Void... voids) {
                return getLatestByNameAndAccountFromBeforeSync(accountId, name, LocalDate.now().minusMonths(1).withDayOfMonth(1).toString(), LocalDate.now().withDayOfMonth(1).toString());
            }
        }, listener);
    }


}
