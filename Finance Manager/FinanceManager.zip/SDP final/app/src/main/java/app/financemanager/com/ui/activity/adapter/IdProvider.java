package app.financemanager.com.ui.activity.adapter;

public interface IdProvider {
    Long getId();
}
