package app.financemanager.com.helper;

import android.os.AsyncTask;

public interface TaskListener {
    void onDone(Object result, AsyncTask<?, ?, ?> task);
}
