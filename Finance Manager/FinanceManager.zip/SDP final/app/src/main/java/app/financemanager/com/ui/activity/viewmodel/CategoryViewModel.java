package app.financemanager.com.ui.activity.viewmodel;

import android.app.Application;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import app.financemanager.com.R;
import app.financemanager.com.domain.database.FinanceDatabase;
import app.financemanager.com.domain.database.dao.CategoryDao;
import app.financemanager.com.domain.model.Category;
import app.financemanager.com.domain.model.Transaction;

public class CategoryViewModel extends TransactionListViewModel {
    private CategoryDao categoryDao = FinanceDatabase.getInstance().categoryDao();
    private long categoryId;
    private LiveData<Category> category;
    private LiveData<Long> categoryBalanceMonth;
    private LiveData<Long> categoryIncomeMonth;
    private LiveData<Long> categoryExpensesMonth;

    public CategoryViewModel(@NonNull Application application, long categoryId) {
        super(application);
        setNavigationDrawerId(R.id.nav_category);
        this.categoryId = categoryId;
        category = categoryDao.get(categoryId);
        categoryBalanceMonth = FinanceDatabase.getInstance().transactionDao().sumForCategoryThisMonth(categoryId);
        categoryIncomeMonth = FinanceDatabase.getInstance().transactionDao().sumIncomeForCategoryThisMonth(categoryId);
        categoryExpensesMonth = FinanceDatabase.getInstance().transactionDao().sumExpensesForCategoryThisMonth(categoryId);
        setNavigationDrawerId(R.id.nav_category);
        setPreselectedCategoryId(categoryId);
        setShowEditMenu(true);
    }

    @Override
    public boolean showDrawer() {
        return false;
    }

    public LiveData<Long> getCategoryIncomeMonth() {
        return categoryIncomeMonth;
    }

    public LiveData<Long> getCategoryExpensesMonth() {
        return categoryExpensesMonth;
    }

    public LiveData<Long> getCategoryBalanceMonth() {
        return categoryBalanceMonth;
    }

    public LiveData<Category> getCategory() {
        return category;
    }

    @Override
    protected LiveData<List<Transaction>> fetchTransactions() {
        return transactionDao.getForCategory(categoryId);
    }

    public static class CategoryViewModelFactory implements ViewModelProvider.Factory {
        private Application application;
        private long categoryId;

        public CategoryViewModelFactory(Application application, long categoryId) {
            this.application = application;
            this.categoryId = categoryId;
        }

        @Override
        public <T extends ViewModel> T create(Class<T> modelClass) {
            return (T) new CategoryViewModel(application, categoryId);
        }
    }
}

