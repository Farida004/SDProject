package app.financemanager.com.ui.activity.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import app.financemanager.com.R;
import app.financemanager.com.domain.model.Category;
import app.financemanager.com.ui.activity.BaseActivity;

public class CategoriesAdapter extends EntityListAdapter<CategoryWrapper, CategoryViewHolder> {
    public CategoriesAdapter(BaseActivity context, LiveData<List<CategoryWrapper>> data) {
        super(context, data);
    }

    @NonNull
    @Override
    public CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View viewItem = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.card_category, parent, false);
        return new CategoryViewHolder(viewItem, context);
    }

    @Override
    public void onBindViewHolder(@NonNull final CategoryViewHolder holder, int index) {
        super.onBindViewHolder(holder, index);
        Category category = getItem(index).getCategory();
        holder.setCategoryName(category.getName());
        holder.setCategoryColor(category.getColor());
        holder.setBudget(getItem(index).getCategory().getBudget());
        getItem(index).getBalance().observe(context, new Observer<Long>() {
            @Override
            public void onChanged(@Nullable Long balance) {
                holder.setBalance(balance);
            }
        });
    }
}
