package app.financemanager.com.ui.activity;

import android.app.FragmentManager;
import android.app.TaskStackBuilder;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.LayoutRes;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.GravityCompat;
import androidx.databinding.DataBindingUtil;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import app.financemanager.com.R;
import app.financemanager.com.databinding.ActivityBaseBinding;
import app.financemanager.com.databinding.ActivityStackedBinding;
import app.financemanager.com.ui.activity.viewmodel.BaseViewModel;

public abstract class BaseActivity extends AppCompatActivity  implements NavigationView.OnNavigationItemSelectedListener {
    public static final int NAVDRAWER_LAUNCH_DELAY = 250;

    public static final int MAIN_CONTENT_FADEOUT_DURATION = 150;
    public static final int MAIN_CONTENT_FADEIN_DURATION = 250;

    // Navigation drawer:
    private DrawerLayout mDrawerLayout;
    private NavigationView mNavigationView;

    private CoordinatorLayout contentWrapper;
    private View content;
    private LayoutInflater inflater;

    private AppBarConfiguration mAppBarConfiguration;

    private Handler mHandler;
    protected SharedPreferences mSharedPreferences;
    protected BaseViewModel viewModel;

    private List<MenuItem.OnMenuItemClickListener> editMenuClickListeners = new ArrayList<MenuItem.OnMenuItemClickListener>();

    protected abstract Class<? extends BaseViewModel> getViewModelClass();

    protected BaseViewModel getViewModel() {
        return ViewModelProviders.of(this).get(getViewModelClass());
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        mHandler = new Handler();
        overridePendingTransition(0, 0);
        viewModel = getViewModel();

        if (viewModel.showDrawer()) {
            ActivityBaseBinding binding = DataBindingUtil.setContentView(this, R.layout.activity_base);
            mNavigationView = binding.getRoot().findViewById(R.id.nav_view);
            mNavigationView.setNavigationItemSelectedListener(this);
            binding.setViewModel(viewModel);
        } else {
            ActivityStackedBinding binding = DataBindingUtil.setContentView(this, R.layout.activity_stacked);
            binding.setViewModel(viewModel);
        }

        viewModel.getTitle().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String title) {
                BaseActivity.this.setTitle(title);
            }
        });

        viewModel.getTitleId().observe(this, new Observer<Integer>() {
            @Override
            public void onChanged(Integer titleId) {
                viewModel.setTitle(getString(titleId));
            }
        });

        viewModel.getNavigationDrawerId().observe(this, new Observer<Integer>() {
            @Override
            public void onChanged(Integer navigationDrawerId) {
                if (navigationDrawerId == null || navigationDrawerId == -1) {
                    selectNavigationItem(-1);
                } else {
                    selectNavigationItem(navigationDrawerId);
                }
            }
        });

        contentWrapper = findViewById(R.id.content_wrapper);
        inflater = LayoutInflater.from(contentWrapper.getContext());
    }

    private void selectNavigationItem(int itemId) {
        if (viewModel.showDrawer()) {
            for (int i = 0; i < mNavigationView.getMenu().size(); i++) {
                boolean b = itemId == mNavigationView.getMenu().getItem(i).getItemId();
                mNavigationView.getMenu().getItem(i).setChecked(b);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_pencil, menu);
        MenuItem menuItemEdit = menu.findItem(R.id.toolbar_action_edit);
        menuItemEdit.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                menuItemEditClicked(item);
                return true;
            }
        });

        return viewModel.doShowEditMenu();
    }

    private void menuItemEditClicked(MenuItem item) {
        for (int i = 0; i < editMenuClickListeners.size(); i++) {
            editMenuClickListeners.get(i).onMenuItemClick(item);
        }
    }

    protected void addEditMenuClickListener(MenuItem.OnMenuItemClickListener listener) {
        editMenuClickListeners.add(listener);
    }

    protected final View setContent(@LayoutRes int layout) {
        if (content != null) {
            contentWrapper.removeView(content);
        }
        content = inflater.inflate(layout, contentWrapper, false);
        contentWrapper.addView(content);
        return content;
    }

    @Override
    public void onBackPressed() {
        if (viewModel.showDrawer()) {
            DrawerLayout drawer = findViewById(R.id.drawer_layout);
            if (drawer.isDrawerOpen(GravityCompat.START)) {
                drawer.closeDrawer(GravityCompat.START);
            } else {
                super.onBackPressed();
            }
        } else {
            super.onBackPressed();
        }
    }

    protected final FloatingActionButton addFab(@LayoutRes int layout) {
        return addFab(layout, null);
    }

    protected boolean goToNavigationItem(final int itemId) {
        if (itemId == viewModel.getNavigationDrawerId().getValue()) {
            // just close drawer because we are already in this activity
            mDrawerLayout.closeDrawer(GravityCompat.START);
            return true;
        }

        // delay transition so the drawer can close
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                callDrawerItem(itemId);
            }
        }, NAVDRAWER_LAUNCH_DELAY);

        mDrawerLayout.closeDrawer(GravityCompat.START);

        selectNavigationItem(itemId);

        // fade out the active activity
        if (contentWrapper != null) {
            contentWrapper.animate().alpha(0).setDuration(MAIN_CONTENT_FADEOUT_DURATION);
        }
        return true;
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        Toolbar toolbar = findViewById(R.id.toolbar);
        if (getSupportActionBar() == null) {
            setSupportActionBar(toolbar);
        }

        if (viewModel.showDrawer()) {

            mDrawerLayout = findViewById(R.id.drawer_layout);
            ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                    this, mDrawerLayout, toolbar, R.string.nav_drawer_toggle_open_desc, R.string.nav_drawer_toggle_close_desc);
            mDrawerLayout.addDrawerListener(toggle);
            toggle.syncState();
        }

        if (contentWrapper != null) {
            contentWrapper.setAlpha(0);
            contentWrapper.animate().alpha(1).setDuration(MAIN_CONTENT_FADEIN_DURATION);
        }
    }

    private void createBackStack(Intent intent) {
        System.out.println("Added to backtrack: " + intent.getComponent().getClassName());
        FragmentManager fm = getFragmentManager();
        System.out.println("Backtrack size: " + fm.getBackStackEntryCount());
        for (int i = 0; i < fm.getBackStackEntryCount(); i++){
            System.out.println("number " + i + ": " + fm.getBackStackEntryAt(i).getId());
        }

        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        TaskStackBuilder builder = TaskStackBuilder.create(this);
        builder.addNextIntentWithParentStack(intent);
        builder.startActivities();
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        final int itemId = item.getItemId();
        return goToNavigationItem(itemId);
    }

    private void callDrawerItem(final int itemId) {
        Intent intent;
        switch (itemId) {
            case R.id.nav_main:
                intent = new Intent(this, TransactionsActivity.class);
                createBackStack(intent);
                break;
            case R.id.nav_category:
                intent = new Intent(this, CategoriesActivity.class);
                createBackStack(intent);
                break;
            case R.id.nav_account:
                intent = new Intent(this, AccountsActivity.class);
                createBackStack(intent);
                break;
            default:
                throw new UnsupportedOperationException("Trying to call unknown drawer item! Id: " + itemId);
        }
    }
    protected final FloatingActionButton addFab(@LayoutRes int layout, View.OnClickListener listener) {
        FloatingActionButton fab = (FloatingActionButton) inflater.inflate(layout, contentWrapper, false);
        contentWrapper.addView(fab);
        if (listener != null) {
            fab.setOnClickListener(listener);
        }
        return fab;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
}
