package app.financemanager.com.ui.activity;


import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import app.financemanager.com.R;
import app.financemanager.com.domain.database.FinanceDatabase;
import app.financemanager.com.helper.FullTaskListener;
import app.financemanager.com.helpers.SharedPreferencesManager;

public class StartupActivity extends AppCompatActivity implements FullTaskListener {
    ProgressBar progressBar;
    TextView progressText;
    boolean keyGen = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferencesManager.init(getApplicationContext());

        setContentView(R.layout.activity_startup);

        getSupportActionBar().hide();
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        progressText = findViewById(R.id.progressText);
        progressBar = findViewById(R.id.progressBar);

        if (FinanceDatabase.getInstance() == null) {
            keyGen = true;
            FinanceDatabase.connect(getApplicationContext(), this);
        } else {
            nextActivity();
        }
    }

    @Override
    public void onDone(Object result, AsyncTask<?, ?, ?> task) {
        nextActivity();
    }

    private void nextActivity() {
        Intent mainIntent = new Intent(this, TransactionsActivity.class);
        mainIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(mainIntent);
        finish();
    }

    @Override
    public void onProgress(final Double progress, AsyncTask<?, ?, ?> task) {
        if (keyGen) runOnUiThread(new Runnable() {
            @Override
            public void run() {
                progressBar.setProgress(Double.valueOf(progress * 1000).intValue());
            }
        });
    }

    @Override
    public void onOperation(final String operation, AsyncTask<?, ?, ?> task) {
        if (keyGen) runOnUiThread(new Runnable() {
            @Override
            public void run() {
                progressText.setText(operation);
            }
        });
    }
}
