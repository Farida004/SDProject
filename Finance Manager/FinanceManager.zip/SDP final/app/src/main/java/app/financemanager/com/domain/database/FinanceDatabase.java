package app.financemanager.com.domain.database;

import android.content.Context;

import java.io.File;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import app.financemanager.com.R;
import app.financemanager.com.domain.convert.LocalDateConverter;
import app.financemanager.com.domain.database.dao.AccountDao;
import app.financemanager.com.domain.database.dao.CategoryDao;
import app.financemanager.com.domain.database.dao.TransactionDao;
import app.financemanager.com.domain.model.Account;
import app.financemanager.com.domain.model.Category;
import app.financemanager.com.domain.model.Transaction;
import app.financemanager.com.helper.CommunicantAsyncTask;
import app.financemanager.com.helper.TaskListener;

@Database(
        entities = {Account.class, Category.class, Transaction.class},
        exportSchema = false,
        version = 10
)
@TypeConverters({LocalDateConverter.class})
public abstract class FinanceDatabase extends RoomDatabase {
    private static final String DB_NAME = "encryptedDB";
    private static InitDatabaseTask initTask;
    private static FinanceDatabase instance;

    public abstract TransactionDao transactionDao();
    public abstract CategoryDao categoryDao();
    public abstract AccountDao accountDao();

      public static FinanceDatabase getInstance() {
        return instance;
    }

    public static CommunicantAsyncTask<?, FinanceDatabase> connect(Context context, TaskListener listener) {
        if (initTask == null) {
            initTask = new InitDatabaseTask(context, DB_NAME);
            if (listener != null) initTask.addListener(listener);
            initTask.execute();
        }
        return initTask;
    }

    private static class InitDatabaseTask extends CommunicantAsyncTask<Void, FinanceDatabase> {

        private Context context;
        private String dbName;

        InitDatabaseTask(Context context, String dbName) {
            this.context = context;
            this.dbName = dbName;
        }

        private boolean dbFileExists() {
            File databaseFile = new File(context.getApplicationInfo().dataDir + "/databases/" + DB_NAME);
            return databaseFile.exists() && databaseFile.isFile();
        }

        @Override
        protected FinanceDatabase doInBackground(Void... voids) {
                publishProgress(0.0);
                publishOperation(context.getResources().getString(R.string.activity_startup_init_key_store_msg));

                publishProgress(.6);
                if (dbFileExists()) {
                } else {
                    publishOperation(context.getResources().getString(R.string.activity_startup_create_and_open_database_msg));
                }
                FinanceDatabase.instance = Room.databaseBuilder(context, FinanceDatabase.class, dbName)
                        .fallbackToDestructiveMigration()
                        .build();

                if (FinanceDatabase.instance.accountDao().count() == 0) {
                    Account defaultAccount = new Account(context.getResources().getString(R.string.activity_startup_default_account_name));
                    defaultAccount.setId(0L);
                    FinanceDatabase.instance.accountDao().insert(defaultAccount);
                }

                return FinanceDatabase.instance;
        }
    }
}
