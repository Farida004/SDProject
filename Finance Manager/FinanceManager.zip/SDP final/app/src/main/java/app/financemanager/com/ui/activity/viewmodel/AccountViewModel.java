package app.financemanager.com.ui.activity.viewmodel;

import android.app.Application;

import org.joda.time.LocalDate;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import app.financemanager.com.domain.database.FinanceDatabase;
import app.financemanager.com.domain.database.dao.AccountDao;
import app.financemanager.com.domain.model.Account;
import app.financemanager.com.domain.model.Transaction;

public class AccountViewModel extends TransactionListViewModel {
    private AccountDao accountDao = FinanceDatabase.getInstance().accountDao();
    private long accountId;
    private LiveData<Account> account;
    private LiveData<Long> totalBalance;
    private LiveData<Long> monthBalance;

    public AccountViewModel(@NonNull Application application, long accountId) {
        super(application);
        this.accountId = accountId;
        account = accountDao.get(accountId);
        totalBalance = FinanceDatabase.getInstance().transactionDao().sumForAccount(accountId);
        monthBalance = FinanceDatabase.getInstance().transactionDao().sumForAccountBefore(accountId, LocalDate.now().withDayOfMonth(1).toString());
        setNavigationDrawerId(null);
        setPreselectedAccountId(accountId);
        setShowEditMenu(true);
    }

    @Override
    public boolean showDrawer() {
        return false;
    }

    public LiveData<Long> getTotalBalance() {
        return totalBalance;
    }

    public LiveData<Long> getMonthBalance() {
        return monthBalance;
    }

    public LiveData<Account> getAccount() {
        return account;
    }

    @Override
    protected LiveData<List<Transaction>> fetchTransactions() {
        return transactionDao.getForAccount(accountId);
    }

    public static class AccountViewModelFactory implements ViewModelProvider.Factory {
        private Application application;
        private long accountId;

        public AccountViewModelFactory(Application application, long accountId) {
            this.application = application;
            this.accountId = accountId;
        }

        @Override
        public <T extends ViewModel> T create(Class<T> modelClass) {
            return (T) new AccountViewModel(application, accountId);
        }
    }
}
