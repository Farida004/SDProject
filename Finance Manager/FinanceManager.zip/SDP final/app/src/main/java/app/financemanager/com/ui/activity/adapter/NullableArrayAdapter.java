package app.financemanager.com.ui.activity.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import app.financemanager.com.R;

public class NullableArrayAdapter<T> extends ArrayAdapter<T> {
    private int resource;
    private int fieldId = 0;
    private LayoutInflater inflater;
    private String nullPlaceholderString;

    public NullableArrayAdapter(Context context, int resource, List<T> objects) {
        super(context, resource, objects);
        this.resource = resource;
        inflater = LayoutInflater.from(context);
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return createViewFromResource(inflater, position, convertView, parent, resource);
    }

    // This method is private in android.widget.ArrayAdapter. IMHO it should be protected.
    protected @NonNull
    View createViewFromResource(@NonNull LayoutInflater inflater, int position,
                                @Nullable View convertView, @NonNull ViewGroup parent, int resource) {
        final View view;
        final TextView text;
        if (convertView == null) {
            view = inflater.inflate(resource, parent, false);
        } else {
            view = convertView;
        }
        try {
            if (fieldId == 0) {
                //  If no custom field is assigned, assume the whole resource is a TextView
                text = (TextView) view;
            } else {
                //  Otherwise, find the TextView field within the layout
                text = view.findViewById(fieldId);
                if (text == null) {
                    throw new RuntimeException("Failed to find view with ID "
                            + getContext().getResources().getResourceName(fieldId)
                            + " in item layout");
                }
            }
        } catch (ClassCastException e) {
            Log.e("ArrayAdapter", "You must supply a resource ID for a TextView");
            throw new IllegalStateException(
                    "ArrayAdapter requires the resource ID to be a TextView", e);
        }
        final T item = getItem(position);
        text.setTextColor(getContext().getResources().getColor(android.R.color.primary_text_light));
        if (item == null) {
            if (nullPlaceholderString == null) {
                nullPlaceholderString = getContext().getResources().getString(R.string.none);
            }
            text.setText(nullPlaceholderString);
            text.setTextColor(getContext().getResources().getColor(android.R.color.tertiary_text_light));
        } else if (item instanceof CharSequence) {
            text.setText((CharSequence) item);
        } else {
            text.setText(item.toString());
        }
        return view;
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
//        final LayoutInflater ddInflater = mDropDownInflater == null ? inflater : mDropDownInflater;
        return createViewFromResource(inflater, position, convertView, parent, resource);
    }
}
