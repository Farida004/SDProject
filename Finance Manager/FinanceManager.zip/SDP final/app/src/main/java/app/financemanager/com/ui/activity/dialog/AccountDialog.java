package app.financemanager.com.ui.activity.dialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import app.financemanager.com.R;
import app.financemanager.com.databinding.DialogAccountBinding;
import app.financemanager.com.domain.model.Account;
import app.financemanager.com.ui.activity.viewmodel.AccountDialogViewModel;

public class AccountDialog extends AppCompatDialogFragment {
    public static final String EXTRA_ACCOUNT_ID = "app.financemanager.com.EXTRA_ACCOUNT_ID";
    public static final String EXTRA_ACCOUNT_MONTH_BALANCE = "app.financemanager.com.EXTRA_ACCOUNT_MONTH_BALANCE";

    private AccountDialogViewModel viewModel;
    private List<Account> allAccounts = new ArrayList<>();

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
            viewModel = ViewModelProviders.of(this).get(AccountDialogViewModel.class);
        viewModel.setInitialMonthBalance(getArguments().getLong(EXTRA_ACCOUNT_MONTH_BALANCE, 0L));
        viewModel.setCurrencyColors(getResources().getColor(R.color.green), getResources().getColor(R.color.red));

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        final DialogAccountBinding binding = DataBindingUtil.inflate(LayoutInflater.from(getContext()), R.layout.dialog_account, null, false);
        View view = binding.getRoot();
        viewModel.setAccountId(getArguments().getLong(EXTRA_ACCOUNT_ID, -1L)).observe(this, new Observer<Account>() {
            @Override
            public void onChanged(@Nullable Account account) {
                viewModel.setAccount(account);
                binding.setViewModel(viewModel);
            }
        });

        viewModel.getAllAccounts().observe(this, new Observer<List<Account>>() {
            @Override
            public void onChanged(@Nullable List<Account> accounts) {
            synchronized (allAccounts) {
                allAccounts = accounts;
            }
            }
        });

        builder.setView(view);

        builder.setTitle(getArguments().getLong(EXTRA_ACCOUNT_ID, -1L) == -1L ? R.string.dialog_account_create_title : R.string.dialog_account_edit_title);

        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int which) {
                viewModel.cancel();
            }
        });

        builder.setPositiveButton(R.string.submit, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int which) {}
        });

        AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateAccountName()) {
                    viewModel.submit(getString(R.string.compensation_transaction_default_name));
                    Toast.makeText(getContext(), R.string.account_saved_msg, Toast.LENGTH_SHORT).show();
                    dismiss();
                }
            }
        });
        return dialog;
    }

    private boolean validateAccountName() {
        synchronized (allAccounts) {
            if (viewModel.getName() == null || viewModel.getName().isEmpty()) {
                Toast.makeText(getContext(), getString(R.string.dialog_account_empty_name_impossible_msg), Toast.LENGTH_LONG).show();
                return false;
            }

            if (allAccounts == null || allAccounts.isEmpty()) {
                return true;
            }
            for (int i = 0; i < allAccounts.size(); i++) {
                if (allAccounts.get(i).getName().toLowerCase().equals(viewModel.getName().toLowerCase()) && allAccounts.get(i).getId() != viewModel.getAccount().getId()) {
                    Toast.makeText(getContext(), getString(R.string.dialog_account_name_taken_msg), Toast.LENGTH_LONG).show();
                    return false;
                }
            }
            return true;
        }
    }
}
