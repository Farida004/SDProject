package app.financemanager.com.ui.activity;

import android.os.Bundle;

import app.financemanager.com.ui.activity.viewmodel.TransactionListViewModel;
import app.financemanager.com.ui.activity.viewmodel.TransactionsViewModel;

public class TransactionsActivity extends TransactionListActivity {

    @Override
    protected Class<? extends TransactionListViewModel> getViewModelClass() {
        return TransactionsViewModel.class;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
