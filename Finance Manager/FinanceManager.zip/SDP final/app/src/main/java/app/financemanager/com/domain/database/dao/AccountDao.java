package app.financemanager.com.domain.database.dao;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Query;
import app.financemanager.com.domain.model.Account;

@Dao
public abstract class AccountDao extends AbstractDao<Account> {
    @Query("SELECT COUNT(*) FROM Account")
    public abstract long count();

    @Override
    @Query("SELECT * FROM Account WHERE id=:id")
    public abstract LiveData<Account> get(long id);

    @Override
    @Query("SELECT * FROM Account")
    public abstract LiveData<List<Account>> getAll();
}