package app.financemanager.com.domain.model;

import androidx.room.PrimaryKey;
import app.financemanager.com.ui.activity.adapter.IdProvider;

public abstract class AbstractEntity implements IdProvider {
    @PrimaryKey(autoGenerate = true)
    private Long id;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
}