package app.financemanager.com.ui.activity.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import app.financemanager.com.R;

public class TransactionsViewModel extends TransactionListViewModel {
    public TransactionsViewModel(@NonNull Application application) {
        super(application);
        setTitle(R.string.activity_transactions_title);
        setNavigationDrawerId(R.id.nav_main);
    }
}
