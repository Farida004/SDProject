package app.financemanager.com.domain.model;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.Index;

@Entity(
        tableName = "Account",
        inheritSuperIndices = true,
        indices = @Index(value = "name", unique = true)
)
public class Account extends AbstractEntity {
    private String name;

    public Account() {
    }

    @Ignore
    public Account(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }
}