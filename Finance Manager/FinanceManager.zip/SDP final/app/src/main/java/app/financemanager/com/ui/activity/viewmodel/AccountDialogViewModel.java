package app.financemanager.com.ui.activity.viewmodel;

import android.app.Application;
import android.os.AsyncTask;

import org.joda.time.LocalDate;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.databinding.Bindable;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import app.financemanager.com.domain.database.FinanceDatabase;
import app.financemanager.com.domain.database.dao.AccountDao;
import app.financemanager.com.domain.database.dao.TransactionDao;
import app.financemanager.com.domain.model.Account;
import app.financemanager.com.domain.model.Transaction;
import app.financemanager.com.helper.TaskListener;

public class AccountDialogViewModel extends CurrencyInputBindableViewModel {
    private AccountDao accountDao = FinanceDatabase.getInstance().accountDao();
    private TransactionDao transactionDao = FinanceDatabase.getInstance().transactionDao();
    private Account account;
    private LiveData<Account> accountLive;
    private Long accountId;
    private long initialMonthBalance = 0;
    private Long monthBalance;
    private String originalName;

    public AccountDialogViewModel(@NonNull Application application) {
        super(application);
    }

    @Override
    protected Long getNumericAmount() {
        return monthBalance;
    }

    @Override
    protected void setNumericAmount(Long amount) {
        monthBalance = amount;
    }

    public LiveData<List<Account>> getAllAccounts() {
        return accountDao.getAll();
    }

    public void updateOrInsert(Account account) {
        accountDao.updateOrInsertAsync(account);
    }

    public void setAccount(Account account) {
        this.account = account;
        originalName = account.getName();
        notifyChange();
    }

    public LiveData<Account> setAccountId(long accountId) {
        if (this.accountId == null || this.accountId != accountId) {
            this.accountId = accountId;
            if (accountId == -1) {
                setAccountDummy();
            } else {
                accountLive = accountDao.get(accountId);
            }
        }
        return accountLive;
    }

    private void setAccountDummy() {
        MutableLiveData<Account> mutable = new MutableLiveData<>();
        mutable.postValue(new Account());
        accountLive = mutable;
    }

    public void setInitialMonthBalance(long initialMonthBalance) {
        this.initialMonthBalance = initialMonthBalance;
        if (monthBalance == null) monthBalance = initialMonthBalance;
    }

    @Bindable
    public String getName() {
        return account.getName();
    }

    public void setName(String name) {
        if (name == null) name = "";
        if (account.getName() == null) account.setName("");
        if (!account.getName().equals(name)) {
            account.setName(name);
        //    notifyPropertyChanged(BR.name);
        }
    }

    public void submit(final String compensationTitle) {
        accountDao.updateOrInsertAsync(account, new TaskListener() {
            @Override
            public void onDone(Object result, AsyncTask<?, ?, ?> task) {
                if (initialMonthBalance != monthBalance) {
                    final Long accountId = (Long) result;
                    transactionDao.getLatestByNameForAccountLastMonthAsync(accountId, compensationTitle, new TaskListener() {
                        @Override
                        public void onDone(Object result, AsyncTask<?, ?, ?> task) {
                            Transaction compensation;
                            if (result != null) {
                                compensation = (Transaction) result;
                            } else {
                                compensation = new Transaction();
                                compensation.setName(compensationTitle);
                                compensation.setAccountId(accountId);
                                compensation.setDate(LocalDate.now().withDayOfMonth(1).minusDays(1));
                                compensation.setAmount(0L);
                            }
                            compensation.setAmount(monthBalance - initialMonthBalance + compensation.getAmount());
                            transactionDao.updateOrInsertAsync(compensation);
                        }
                    });
                }
            }
        });
    }

    public void cancel() {
        account.setName(originalName);
    }

    public Account getAccount() {
        return account;
    }
}
